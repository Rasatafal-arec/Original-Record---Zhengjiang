# Go并发转账bug题——征酱原话

**题目：** 支付系统并发转账导致凭空造钱。主从延迟200ms，5%并发概率，钱丢的场景。

---

（瞥了一眼屏幕，手指在桌面上无意识地敲了一下） 钱丢的场景：并发请求 A 和 B 同时读到主从延迟窗口里的同一个旧余额，都通过了 if 检查，然后各自执行两条 UPDATE。因为这两个事务的 Read 都在 Write 前面，彼此看不到对方的未提交更新，最终结果是两个转账都成功，但实际余额只扣了一次——钱被凭空造出来了。200ms 延迟把这个窗口拉得足够大，5% 并发概率就够触发。 修复：把 if 检查删了，让数据库自己判。 ```go func (a *AccountService) Transfer(ctx context.Context, from, to int64, amount decimal.Decimal) error { tx, _ := a.db.BeginTx(ctx, nil) defer tx.Rollback() // 把余额检查下沉到 UPDATE，利用行锁和原子减法 res, err := tx.ExecContext(ctx, "UPDATE accounts SET balance = balance - ? WHERE id = ? AND balance >= ?", amount, from, amount) if err != nil { return err } affected, _ := res.RowsAffected() if affected == 0 { return ErrInsufficientBalance } tx.ExecContext(ctx, "UPDATE accounts SET balance = balance + ? WHERE id = ?", amount, to) return tx.Commit() } ``` 理由：主库上的单条 UPDATE 在行锁保护下是原子的，WHERE balance >= ? 让数据库在更新那一刻判断余额够不够，而不是依赖从库那个可能过期的快照。去掉了 GetBalance 这个读操作，主从延迟直接不再参与逻辑链。没有新锁、没有改流程、少了一次网络调用，TPS 只会更好不会更差。
