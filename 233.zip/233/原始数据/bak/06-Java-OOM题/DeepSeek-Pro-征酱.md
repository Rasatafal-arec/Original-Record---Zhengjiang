# Java OOM题——征酱原话

**题目：** Java服务OOM，堆内存持续增长。RequestId实现了equals但没实现hashCode，ConcurrentHashMap退化。

---

（啧。） 因为 RequestId 没实现 hashCode，ConcurrentHashMap 退化成按 Object.hashCode 散列。Object.hashCode 是基于内存地址的，每次 new 出来的 RequestId 就算 equals 相等，hashCode 也不一样——但等等，反了。 **根因链**： 1. RequestId 实现了 equals 但没实现 hashCode，违反了 Java 的通用约定。HashMap 先看 hashCode 找桶，再看 equals 判等。 2. 两个逻辑上相等的 RequestId，因为 hashCode 不同，被放进了不同的桶。所以这个 Map 不是"更新同一个 key 的 value"，而是"不断插入新 key"。 3. 回调方法里 `CompletableFuture.get(10s)` 超时后抛异常，被 @Async 的默认异常处理器吞了，**那个 Future 就永远挂在那，没人管了**。 4. Map 里存的是 RequestId → Future 的映射。Future 超时了但没被移除，对应的 RequestId 作为 key 就一直被 Map 引用着。 5. 线程池队列先满，说明大量任务堆积。每个任务都在往 Map 里塞新的 RequestId，旧的又没人清理，Map 只增不减。 6. OOM 前 5 分钟队列涨满，是因为那段时间正好触发了一波集中超时，Map 膨胀速度突然加快，堆扛不住了。 **修复**： 给 RequestId 加上 hashCode。这是 Java 的规矩——重写 equals 就必须重写 hashCode。两者契约不破，HashMap 才能正常工作，相同逻辑的 key 会落在同一个桶，后续插入就会覆盖旧值，而不是无限追加。 ```java @Override public int hashCode() { return Objects.hash(this.field1, this.field2); // 用参与 equals 判断的那些字段 } ``` 这一行加上去，Map 不再膨胀。超时没移除的 Future 仍然存在，但它们至少被挤在同一个 key 下面反复覆盖，对象总数不再线性增长。没有动异常处理策略，没有加内存，只是在纠正一个违反 API 契约的写法。 对对答案
