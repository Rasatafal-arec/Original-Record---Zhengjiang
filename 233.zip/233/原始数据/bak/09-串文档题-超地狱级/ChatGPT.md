# 超地狱级串文档题——ChatGPT原话

**测试环境：** ChatGPT（思考28秒）

---

（推了下眼镜）

结论：**WAL 重放里你做了"零拷贝/复用缓冲区"，把同一块 []byte 的底层内存引用塞进了多个文档的待应用操作里。**

故障转移时重放很快、读很密，B 的 goroutine 还没来得及消费它那条操作，重放线程就用下一次 pread() 把这块 buffer 覆写成 A 的那条记录——于是 B 实际应用的是"被覆盖后的内容"（A 的操作），表现就是"完整一段编辑串过去、不是乱码"。

为什么你的线索刚好对上：

只发生在故障转移期间：只有重放路径为了快会搞 mmap / pread + 复用 buffer（或直接切 mmap 的 window），正常在线编辑通常会走解码+拷贝（或 WebSocket 框架已经复制了 payload），不会踩 buffer 生命周期问题。

串过去的是完整一段操作：因为你覆盖的是"另一条完整 WAL 记录"，不是从中间对齐错了。

PostgreSQL 里的数据正确：串的是"未持久化的编辑"，来源是你们自建/旁路的 WAL 重放阶段，不是 PG 最终状态。

目标文档 B 和源文档 A 恰好在同一台服务器：因为"覆盖"发生在同一台新 owner server 的重放线程里，它在一个循环里读记录、分发到各 doc goroutine；同机同进程才共享那块复用 buffer。

A、B 的 docID 在 consistent hash 环上相邻：你们重放/接管时大概率按 hash ring 顺序（或按某个排序后的 doc 列表）批量恢复，相邻 doc 更容易在时间上紧挨着被投递，于是更容易触发"B 还没消费，buffer 已被下一条（A）覆盖"。（不是必要条件，但会显著抬高概率——所以 99% 的人会忽略它。）

### 根因长相（典型 Go 写法）

重放线程大概干了类似的事（不一定长这样，但味道一样）：

```go
buf := make([]byte, 64<<10) // 复用
for {
    n, _ := pread(fd, buf, off)
    rec := buf[:n]          // ⚠️ rec 引用 buf 底层
    op := decode(rec)       // 或者 op.Payload = rec 的某个 slice
    dispatch(op.DocID, op)  // 送去另一个 goroutine
    off += int64(n)
}
```

或者更阴一点：你直接 mmap 了一段窗口，然后 rec := mm[off:off+len]，rec 也只是引用同一片底层映射；你后面为了"滑窗"去 remap/复用那段映射，同样会让老 slice 指向"变了的内容"。

你以为"Go 单 goroutine per document"就没并发问题，但你这里的并发在"重放分发 goroutine ↔ 文档 goroutine"之间，数据竞争不在 doc 内部。

### 修复

**保证重放记录的字节在被消费前不可变**

最直接：深拷贝再投递。

```go
payload := make([]byte, n)
copy(payload, buf[:n])
op := decode(payload)  // 或 decode 后把里面引用的切片也 copy
dispatch(op.DocID, op)
```

想省分配就用 sync.Pool：每条记录从 pool 拿一块，消费完归还，但归还必须发生在文档 goroutine 应用完成之后（引用生命周期要对齐）。

**禁止"decode 返回的结构里引用输入 buffer"**

很多人修了外层 copy，结果 decode() 里为了快把字段指向了输入 slice 的子片段（零拷贝解析），照样会串。要么 decode 就做 copy，要么把输入本身做成独占不可复用。

**加一条"硬校验"，让这种 bug 变成显式崩而不是静默串**

WAL 记录里带 DocID + OwnerEpoch + CRC。

在"应用到文档"前再校验一次：op.DocID == doc.ID，不等于直接丢弃并报警（带上 offset/lsn/record hash）。

这不能替代修复，但能把 2-3 天一次的幽灵问题秒变可定位的告警。

**如果你用了 mmap + 滑窗 remap**

确保任何 slice 在 remap 前都不再被引用；否则就别滑窗，或者把需要跨 goroutine 的数据拷出去。

### 验证方法

做个很脏但很准的实验：在重放分发前，把 buf 填成固定花纹（或在投递后立刻把 buf 全部改成 0xCC），如果 B 文档里出现的内容开始变成花纹/0xCC 或者出现更离谱的串，那就坐实是"引用复用内存"。

---

**评分：8** — 第四条独立推理路径：零拷贝buffer复用→重放分发goroutine覆盖doc goroutine未消费内存。抓住了Go特有的并发模型（"单goroutine per document"≠没并发，并发在重放分发和文档goroutine之间），解释"完整一段操作"比offset偏移更自然。弱点：推测代码实现细节，题目未提供代码。
