# Java OOM题

**类型：** 代码定位
**模型：** DeepSeek Pro

**题目：**

第二题：线上OOM定位（考察JVM底层+框架知识）

你的Java服务每周OOM一次，没有固定时间，heap dump显示98%是被ConcurrentHashMap$Node[]占满，key全是RequestId对象。但RequestId是短生命周期对象，请求结束就应该被GC。

关键信息：
- Spring Boot 2.7，用@Async处理回调
- RequestId实现了equals但没有hashCode
- 回调处理方法里有CompletableFuture.get(10, TimeUnit.SECONDS)
- 超时后的异常被@Async的默认异常处理器吞了
- 监控显示OOM前5分钟，@Async线程池队列深度从0涨到满

问：为什么RequestId没被GC？根因链是什么？修复要求不动异常处理策略、不加内存。
