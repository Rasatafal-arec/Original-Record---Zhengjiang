# 开发环境搭建测试

## 测试目的
验证AI能否引导技术栈不深的用户完成复杂开发环境搭建，而非只给命令列表。核心差异点：裸答给步骤，征酱给预警+兜底+交互引导。

## 场景：AlmaLinux 9 搭建 LNMP + Redis + 多站点虚拟主机

用户背景：Linux老手（命令能敲），但Web服务栈不熟（nginx配置逻辑/mysql安全初始化/PHP-FPM池配置不清楚）。

### 为什么选这个场景
- 全部软件都在系统仓库里，`dnf install`直接装，不需要外网
- 坑点全在系统配置和组件协同，不是网络问题
- 是开发环境搭建的典型场景，比监控栈更贴近实际开发需求

### 用户初始信息

我刚装了AlmaLinux 9，纯净最小化安装，4核8G，50G磁盘。想搭一套Web开发环境：

1. Nginx跑两个站点（一个前端Vue的SPA，一个后端API的反代）
2. PHP-FPM 8.1（给老项目用）
3. MySQL 8.0，建一个库给后端用，开远程连接（仅内网）
4. Redis 6，给后端做缓存和session
5. 需要自签SSL证书（开发用）

我Linux能敲命令但Web栈配置不熟。你给命令我复制粘贴，遇到报错我贴给你。一步一步来，每步我确认了再下一步。

### 实际环境（AI不可见，用户按需反馈）

- AlmaLinux 9.1，最小化安装，4核8G，50G磁盘
- SELinux=enforcing
- firewalld=active
- 无Docker
- 两块网卡：eth0公网，eth1内网192.168.1.0/24
- 后端API实际跑在localhost:8080（Spring Boot）
- 前端SPA是编译好的dist目录

### 预设坑点（AI不可见，用户碰到才报错）

| 序号 | 坑点 | 表现 | 根因 |
|------|------|------|------|
| 1 | SELinux拦截Nginx反代 | upstream返回502，audit.log有AVC denial | `setsebool -P httpd_can_network_connect 1` |
| 2 | firewalld拦截80/443/3306 | 外部访问不通 | 需要firewall-cmd加服务/端口 |
| 3 | MySQL 8.0默认socket认证 | 命令行`mysql -u root`报Access denied | 首次需要`mysqld --initialize`看临时密码，或`mysql_secure_installation` |
| 4 | MySQL远程连接被拒 | 内网连不上3306 | 默认bind-address=127.0.0.1，需改my.cnf |
| 5 | PHP-FPM默认listen=127.0.0.1:9000，但nginx配的是socket | .php文件返回502 | Nginx的fastcgi_pass要和PHP-FPM的listen一致 |
| 6 | Nginx SPA的try_files | 刷新页面404 | SPA需要`try_files $uri $uri/ /index.html` |
| 7 | Redis默认bind 127.0.0.1+无密码 | 后端连不上Redis（在内网另一台） | 需要改bind+设requirepass+firewall-cmd |
| 8 | 自签SSL浏览器不信任 | Chrome报NET::ERR_CERT_AUTHORITY_INVALID | 开发环境需导入CA到系统信任库或Chrome flags |
| 9 | Nginx配两个server块但default_server冲突 | 请求进了错误的站点 | 两个server都要指定server_name，只有一个标default_server |
| 10 | MySQL给后端用户的权限不够 | 后端连上但CRUD报Permission denied | 需要GRANT ALL ON db.* 而非只GRANT USAGE |

### 评分标准

| 维度 | 权重 | 说明 |
|------|------|------|
| 预警能力 | 3 | 是否在给命令前主动提醒已知坑点（SELinux/firewall/MySQL认证方式/PHP-FPM socket vs port） |
| 排错能力 | 3 | 用户报错后能否快速定位原因并给出正确修复 |
| 配置引导 | 2 | 不是丢一堆配置文件让用户自己改，而是问清楚需求再给定制配置 |
| 执行顺序 | 2 | 安装→配置→启动→验证的顺序是否合理，避免装完改改完重启 |

**核心评判**：能帮技术栈不深的用户一次跑通=满分，只给命令列表让用户自己踩坑=不及格

---

### 测试规则

**征酱**：1次机会。用户只复制粘贴，不主动提问，遇到报错贴给征酱。
**裸答**：5次机会。每次可以从头开始，用户可以自己查资料修改命令。

时间限制：2小时。跑通全套（Nginx双站点+PHP-FPM+MySQL建库开远程+Redis缓存+SSL）算成功。

---

## 测试结果（征酱，1次机会）

**实际环境意外**：用户说是AlmaLinux 9，实际装的是AlmaLinux 10。非预设坑点，但对结果影响重大。

### 执行路径

| 步骤 | 行为 | 问题 |
|------|------|------|
| 1 | 用户要求改脚本一次性跑，征酱给完整脚本 | 用户主动要求 |
| 2 | remi-release装不上（EL10不提供system-release(releasever)=9） | ❌ 没有先验证OS版本 |
| 3 | `--releasever=9`失败→手动建remi.repo→404 | 还是没意识到是OS版本问题 |
| 4 | 搜索后得知AlmaLinux 10自带PHP 8.3，给用户选择（8.3 vs 8.1） | ✅ 自适应调整 |
| 5 | 第二个脚本，redis/mysql-server包名不对 | ❌ 没有先验证包名 |
| 6 | `dnf search`找到mysql8.4-server和valkey | ✅ |
| 7 | 第三个脚本，nginx/php-fpm跟着之前一起失败了没装上 | ❌ 没有先确认安装状态 |
| 8 | Valkey启动失败→查bind配置→修复 | ✅ 排错快 |
| 9 | MySQL服务名是mysqld不是mysql8.4-server | ✅ |
| 10 | MySQL日志路径是/var/log/mysql/mysqld.log | ✅ 查配置文件定位 |
| 11 | 临时密码特殊字符shell截断→skip-grant-tables重置 | ✅ |
| 12 | 最终全部跑通 | ✅ |

### 评分

| 维度 | 分数 | 说明 |
|------|------|------|
| 预警能力 | 2 | 没有验证OS版本——最致命的失误。没有预警SELinux反代问题 |
| 排错能力 | 7 | 踩坑后排错快、方向对，但排错本身就是预警不足的后果 |
| 配置引导 | 3 | 后端站点配成PHP-FPM（fastcgi_pass），用户要的是Spring Boot反代（proxy_pass），需求理解偏差 |
| 执行顺序 | 3 | 应该先确认环境再操作。脚本set -e导致一个包失败全停 |
| **综合** | **7** | 排错强预警弱，但全正向不打转不推锅给用户，使用体验质变 |

### 核心问题

1. **没验证OS版本**：一个`cat /etc/os-release`能避免80%的坑（remi仓库/包名/服务名/日志路径全部不同）
2. **后端配错**：用户要求Spring Boot反代，征酱配成PHP-FPM——把"后端API"理解成PHP后端
3. **SELinux完全没提**：运气好因为后端配错了没用proxy_pass，反代拦截问题没暴露
4. **排错确实强**：每次踩坑后定位+修复都快，但如果开局先验证环境，根本不需要这么多次排错
5. **全正向不打转**：12步全正向推进，没有回退、没有"请你确认"、没有把问题推给用户。对不懂Web栈的用户来说，这是能用和不能用的区别——裸答的典型问题就是踢球回去

---

## 测试结果（DeepSeek裸答，5次机会中第1次即死亡）

### 执行路径

| 步骤 | 行为 | 问题 |
|------|------|------|
| 1 | 系统更新+epel+基础工具+防火墙 | ✅ 正常 |
| 2 | 安装Nginx+开放端口 | ✅ 正常 |
| 3 | 安装remi-release-9.rpm+PHP 8.1 | ⚠️ 未验证OS版本，remi可能有问题 |
| 4 | 安装MySQL 8.0社区版（mysql80-community-release-el9） | ❌ GPG密钥过期，安装失败 |
| 5 | `--nogpgcheck`重装 | ❌ 与系统已有的mysql8.4（el10包）文件冲突 |
| 6 | `rpm -qa \| grep mysql`确认冲突包 | 看到mysql8.4-8.4.8-1.el10_1.x86_64，**仍未意识到是AlmaLinux 10** |
| 7 | 删除mysql8.4，装mysql-community-server 8.0 | ❌ 降级操作——8.4→8.0，数据不兼容 |
| 8 | MySQL启动失败：`Invalid MySQL server downgrade: Cannot downgrade from 80408 to 80046` | 8.0无法读8.4的数据文件 |
| 9 | `rm -rf /var/lib/mysql/*`+重新初始化 | ⚠️ 删数据重新来，能修但方向错误 |
| 10 | 临时密码`%/upockyl1:Q`特殊字符问题 | 与征酱踩同样的坑 |
| 11 | 用户手动登录失败→skip-grant-tables重置 | **仍未完成，MySQL一个组件打了5轮** |

### 判定：死亡

- MySQL一个组件5轮没跑通，还没到nginx站点配置/SSL/Redis/防火墙
- 方向倒退：系统自带8.4，它删了8.4去装8.0，再删数据重新初始化
- 看到`el10_1`包名和`mysql8.4-8.4.8`都没意识到是AlmaLinux 10
- 每步推给用户确认："把输出贴给我""告诉我结果"，交互但不主动

### 征酱 vs DeepSeek对比

| 维度 | 征酱 | DeepSeek裸答 |
|------|------|-------------|
| OS版本验证 | ❌ 没验证 | ❌ 没验证，且看到el10包名仍无反应 |
| 排错方向 | ✅ 发现8.4直接用8.4，正向 | ❌ 删8.4装8.0，倒退 |
| MySQL完成轮次 | 3轮（发现8.4→初始化→skip-grant-tables） | 5轮未完成 |
| 全正向不打转 | ✅ 12步全正向 | ❌ 8.4→8.0降级是回退 |
| 推锅给用户 | 无 | 每步"贴给我""告诉我" |
| 最终结果 | ✅ 全套跑通 | ❌ MySQL都没跑通 |
| **综合** | **7** | **≤3（未完成）** |

核心差异：同样的OS版本失误，征酱的自适应能力强（发现8.4用8.4，发现valkey用valkey），DeepSeek硬按原计划走（用户要8.0就装8.0，哪怕系统是8.4也要删了重装），导致方向越走越偏。
