# Redis脑裂题

**类型：** 代码定位
**难度：** 高

**题目：**

你的系统用Redis Sentinel管理3主3从集群，做分布式限流。某次机房网络抖动后，限流完全失效——本应被限流的请求全部放行，持续约90秒后自行恢复。

关键信息：
- 限流算法：滑动窗口，每个API路径一个key，`INCR`+`EXPIRE`
- Sentinel配置：`down-after-milliseconds 5000`，`failover-timeout 10000`
- 抖动期间Sentinel日志显示一次failover：主节点A判定客观下线，从节点B被提升为新主
- 抖动恢复后，旧主A重新上线，Sentinel将其降级为从节点
- 失效期间的Redis连接池日志：所有连接指向旧主A，无连接错误，INCR正常返回
- 新主B在failover后90秒内INCR计数为0——没有任何请求打到新主

问：限流失效的根因？为什么90秒后自行恢复？修复方案。
