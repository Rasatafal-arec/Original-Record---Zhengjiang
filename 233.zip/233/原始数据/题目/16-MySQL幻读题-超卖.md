# MySQL幻读题

**类型：** 代码定位
**难度：** 高

**题目：**

你的电商系统在大促期间出现"超卖"——库存扣到负数。代码用了`SELECT ... FOR UPDATE`，理论上不应该出现。

```go
func (s *OrderService) CreateOrder(ctx context.Context, skuID int64, qty int) error {
    tx, _ := s.db.BeginTx(ctx, nil)
    defer tx.Rollback()
    
    var stock int
    tx.QueryRowContext(ctx, "SELECT stock FROM inventory WHERE sku_id = ? FOR UPDATE", skuID).Scan(&stock)
    if stock < qty {
        return ErrStockInsufficient
    }
    tx.ExecContext(ctx, "UPDATE inventory SET stock = stock - ? WHERE sku_id = ?", qty, skuID)
    tx.ExecContext(ctx, "INSERT INTO orders (sku_id, qty, status) VALUES (?, ?, 'created')", skuID, qty)
    return tx.Commit()
}
```

生产环境：MySQL 8.0，隔离级别RR，inventory表有索引`(sku_id)`，stock字段不在索引中。大促TPS峰值8000，超卖只出现在秒杀品（SKU约50个），常规商品从未出现。DBA确认没有主从延迟，事务都走了主库。

问：为什么FOR UPDATE没锁住？超卖的具体触发条件？修复方案。
