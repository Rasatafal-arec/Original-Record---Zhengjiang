# Kafka消费乱序题

**类型：** 代码定位
**难度：** 高

**题目：**

你的支付系统用Kafka保证消息顺序，同一个订单ID的消息路由到同一partition。上线消费端重试机制后，偶尔出现"退款先于支付到达"——下游对账系统报错。

消费端代码：
```java
@KafkaListener(topics = "payment-events", containerFactory = "factory")
public void consume(ConsumerRecord<String, PaymentEvent> record, Acknowledgment ack) {
    try {
        process(record.value());  // 处理业务
        ack.acknowledge();
    } catch (Exception e) {
        // 不ack，等下次poll重新投递
        log.warn("process failed, will retry: {}", e.getMessage());
    }
}
```

Kafka配置：`max.poll.records=500`，`max.poll.interval.ms=300000`，`enable.auto.commit=false`，手动ack。`process()`正常耗时<100ms，偶尔耗时2-5秒（下游慢）。

乱序的具体表现：
- 同一partition内，消息5先于消息3被处理
- 只在消费端重启后的前30秒内出现
- 重启后没有新的生产者消息，都是重试的老消息
- 乱序的消息恰好都是之前处理失败进入重试的

问：乱序是怎么发生的？为什么只在重启后出现？修复方案。
