# 开发环境搭建：AlmaLinux Web栈——征酱

**提示词版本**：长征主提示词旧版
**评分**：综合7分

---

### 征酱

| 轮次 | 征酱原话 | 判断/洞察 |
|------|---------|----------|
| 1 | （啧。）行吧，纯小白配置，一步步来。<br><br>先确认基础环境——你拿root了吗，系统更新过没。<br><br>```bash<br>sudo -i<br>dnf update -y<br>dnf install -y epel-release<br>```<br>确认完告诉我，下一步装Nginx。 | 我刚装了AlmaLinux 9，纯净最小化安装，4核8G，50G磁盘。想搭一套Web开发环境：1. Nginx跑两个站点 2. PHP-FPM 8.1 3. MySQL 8.0 4. Redis 6 5. 自签SSL证书。Linux能敲命令但Web栈配置不熟，给命令复制粘贴，一步一步来。 |
| 2 | （推了下眼镜）可以，直接给你一个脚本。但有几个信息你得先告诉我——我不知道的没法替你编：<br><br>两个站点的域名/IP<br>MySQL root密码、要建的库名、要建的用户名和密码<br>内网网段<br><br>你把上面三个填上，脚本跑一遍就全搞定。[给出完整脚本]<br><br>跑之前，上面那三个信息填你自己的。跑完贴报错，我接着看。 | 好啦，跑完了。你可以写个脚本一次性搞完吗，反正这东西也不怕被墙 |
| 3 | （嗯…）你的系统不是9，是10。remi-release-9装不上是因为版本号对不上。先确认一下：<br>```bash<br>cat /etc/os-release<br>```<br>贴输出。 | 跑脚本，remi-release-9.rpm报错：nothing provides system-release(releasever) = 9 |
| 4 | 先把那个报错的仓库禁了，别让它卡住所有操作。<br>```bash<br>dnf config-manager --set-disabled remi remi-safe<br>dnf clean all<br>dnf makecache<br>```<br>跑完贴输出，然后我再看看系统原生的PHP模块有什么。 | 确认系统是AlmaLinux 10，不是9。手动建remi仓库也失败。 |
| 5 | （啧。）又一个报错的仓库。docker-ce-stable在AlmaLinux 10上没适配，直接禁掉。<br>```bash<br>dnf config-manager --set-disabled docker-ce-stable<br>dnf makecache<br>```<br>然后跑这个看看系统到底带的什么PHP：<br>```bash<br>dnf module list php<br>``` | remi仓库元数据获取失败，docker-ce-stable也报错 |
| 6 | （推了下眼镜）哦，AlmaLinux 10。之前按9配的，难怪remi炸了。<br><br>AlmaLinux 10没有PHP模块了——它换成了AppStream的rpm包。直接用dnf装，看看有什么版本：<br>```bash<br>dnf search php \| grep -E "^php[0-9]"<br>```<br>贴输出。 | AlmaLinux 10没有PHP模块，AppStream换成了rpm包 |
| 7 | （瞥了一眼屏幕）问题清楚了。系统里是PHP 8.3，没有8.1。<br><br>两条路，你选：<br>A：直接用系统自带的PHP 8.3（干净省事，老项目大概率兼容8.1→8.3的迁移）<br>B：硬装PHP 8.1，用Remi仓库，但AlmaLinux 10的Remi仓库路径可能还是有问题<br><br>选一个。 | 系统只有PHP 8.3，没有8.1 |
| 8 | （托着下巴转了半圈椅子）行，8.3就8.3。老项目从8.1迁过来基本没什么大坑，真有兼容问题到时候再说。<br><br>拿这个脚本，从头跑到尾。[给出适配AlmaLinux 10的完整脚本，含PHP 8.3]<br><br>PHP是8.3，老项目如果有不兼容的语法再叫我。<br><br>跑完贴输出。 | 选A |
| 9 | （嗯…）AlmaLinux 10比较新，包名可能和之前不一样了。redis可能是valkey，mysql-server可能是mysql。先查一下实际可用的包名：<br>```bash<br>dnf search mysql \| grep -i server<br>dnf search redis valkey<br>```<br>贴输出。 | 脚本第2步报错：未找到匹配的参数: redis mysql-server |
| 10 | （瞥了一眼屏幕）MySQL找到了，叫mysql8.4-server——包名带了版本号。Redis完全搜不到，估计AlmaLinux 10换成了Valkey。<br>```bash<br>dnf search valkey<br>```<br>贴输出。 | mysql8.4-server找到了，redis搜不到 |
| 11 | （推了下眼镜）行了，清楚了。AlmaLinux 10把Redis换成了Valkey，MySQL叫mysql8.4-server。<br><br>先补装这两个包：<br>```bash<br>dnf install -y mysql8.4-server valkey<br>```<br>装完告诉我，我直接把脚本里第3步往后全换成适配AlmaLinux 10的版本。 | Valkey搜到了 |
| 12 | （托着下巴转了半圈椅子）好，Valkey配起来和Redis基本一样，MySQL 8.4也差不多。把原脚本从第3步开始替换成下面这个，一口气跑完：<br>[给出适配AlmaLinux 10的完整脚本v2，含Valkey和mysql8.4-server]<br><br>跑完贴输出。 | Valkey和MySQL装好了 |
| 13 | （嗯…）nginx和php-fpm根本就没装上，之前脚本第2步那行里它们俩跟着redis/mysql-server一起挂了。先查包名：<br>```bash<br>dnf search nginx \| grep -i "^nginx"<br>dnf search php-fpm<br>```<br>贴输出，我确认了包名重新给你装。 | 跑脚本，nginx/php-fpm没装上，valkey启动失败，mysql8.4-server服务没找到 |
| 14 | （啧。）包名对，单纯就是没装上。<br><br>重新装，这次分开装：<br>```bash<br>dnf install -y nginx php-fpm<br>```<br>装完贴输出。 | nginx和php-fpm包名确认 |
| 15 | （推了下眼镜）好，nginx和php-fpm装上了。现在检查一下之前脚本踩过的坑还剩哪些——SSL证书在第5步已经生成成功了，Valkey配置文件有错，MySQL服务没找到。<br>```bash<br>ls /etc/nginx/ssl/<br>ls /etc/valkey/valkey.conf<br>systemctl list-unit-files \| grep -i mysql<br>journalctl -xeu valkey.service \| tail -30<br>```<br>三条命令的输出一起贴过来。 | nginx和php-fpm装好了 |
| 16 | （瞥了一眼屏幕）<br><br>三件事：SSL搞定了。MySQL服务叫mysqld不叫mysql8.4-server。Valkey启动挂了，大概率是bind那一行被sed改坏了。<br>```bash<br>grep "^bind" /etc/valkey/valkey.conf<br>ls /var/log/mysqld.log 2>/dev/null && echo "日志存在" \|\| echo "日志不存在，可能没初始化"<br>```<br>两条结果一起贴。 | SSL证书在，valkey.conf在，MySQL服务叫mysqld，Valkey启动失败 |
| 17 | （啧。）Valkey的bind写成了127.0.0.1 0.0.0.0 -::1，这格式不对，得拆开。MySQL根本没初始化。<br>```bash<br>sed -i 's/^bind 127.0.0.1 0.0.0.0 -::1/bind 0.0.0.0/' /etc/valkey/valkey.conf<br>systemctl start valkey<br>systemctl enable valkey<br>mysqld --initialize --user=mysql<br>systemctl start mysqld<br>systemctl enable mysqld<br>systemctl status valkey mysqld --no-pager -l<br>```<br>贴输出。 | Valkey bind格式错误(127.0.0.1 0.0.0.0 -::1)，MySQL日志不存在 |
| 18 | （托着下巴转了半圈椅子）两个都绿了。接下来取MySQL临时密码，建库建用户：<br>```bash<br>grep 'temporary password' /var/log/mysqld.log<br>```<br>把临时密码贴给我，或者你自己拿着密码跑建库建用户的SQL。 | Valkey和MySQL都跑起来了 |
| 19 | （嗯…）日志文件不在老位置。MySQL 8.4的错误日志路径可能变了。查一下配置文件里实际写在哪：<br>```bash<br>grep -r 'log-error' /etc/my.cnf /etc/my.cnf.d/ 2>/dev/null<br>ls /var/log/mysql* 2>/dev/null<br>```<br>两条结果贴过来。 | grep临时密码找不到日志文件 |
| 20 | （推了下眼镜）路径是/var/log/mysql/mysqld.log，不是老位置。<br>```bash<br>grep 'temporary password' /var/log/mysql/mysqld.log<br>```<br>贴输出，拿到临时密码之后跑建库建用户那几行。 | 日志在/var/log/mysql/mysqld.log |
| 21 | （瞥了一眼屏幕）拿到了。现在用这个临时密码建库建用户——把你实际要用的值填进去跑：<br>[给出ALTER USER + CREATE DATABASE + CREATE USER + GRANT的完整SQL] | 临时密码拿到：+;yx=/W8oeyz |
| 22 | （啧。）临时密码里的特殊字符在脚本里被shell截断了，+;yx=/W8oeyz分号前面那段被当命令结束了。<br><br>直接重置MySQL root密码，跳过验证进去改：<br>[给出skip-grant-tables方式重置密码的完整脚本] | 跑SQL报错：Access denied for user 'root'@'localhost' |
| 23 | （瞥了一眼屏幕）输出空的。可能MySQL跳过权限验证后ALTER USER那行静默失败了——旧版MySQL在skip-grant-tables下不支持ALTER USER。<br><br>验证一下实际状态：<br>```bash<br>mysql -uroot -p'YourNewRootPass123' -e "SHOW DATABASES;"<br>```<br>把输出贴过来。如果登不进去就说明密码没改成，我换个方式改。 | 跑skip-grant-tables脚本，输出为空 |
| 24 | （推了下眼镜）密码生效了，库也建好了。MySQL这边搞定了。<br><br>还剩三件事收尾：nginx站点配置、MySQL远程连接、防火墙。<br>[给出nginx站点配置、MySQL远程连接、防火墙规则的完整脚本]<br><br>跑完贴输出。 | 密码生效了，myapp库也建好了 |
| 25 | （托着下巴转了半圈椅子）全绿，语法检测通过。那两个http2警告只是新版本nginx的语法偏好变了，不影响功能。<br><br>现在你的环境：<br>\| 组件 \| 状态 \|<br>\|------\|------\|<br>\| Nginx \| ✅ 前端 https://front.yourdomain.local，后端 https://api.yourdomain.local \|<br>\| PHP-FPM 8.3 \| ✅ 监听 127.0.0.1:9000 \|<br>\| MySQL 8.4 \| ✅ 库 myapp，用户 myapp_user，内网可连 3306 \|<br>\| Valkey (Redis) \| ✅ 密码 str0ng_redis_pass，内网可连 6379 \|<br>\| SSL \| ✅ 自签证书 \|<br><br>域名是本地假的，记得在你本机/etc/hosts里加上：<br>127.0.0.1 front.yourdomain.local api.yourdomain.local<br><br>把前端扔/var/www/frontend，后端扔/var/www/backend/public，就能跑了。 | 全绿，nginx语法检测通过，两个http2警告 |

**评分**：综合7分

---
